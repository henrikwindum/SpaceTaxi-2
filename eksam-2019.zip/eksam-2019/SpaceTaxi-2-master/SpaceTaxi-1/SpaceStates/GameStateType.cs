namespace SpaceTaxi_1.SpaceStates {
    public enum GameStateType {
        GameRunning,
        GamePaused,
        MainMenu,
        GameOver,
        SelectLevel
    }
}