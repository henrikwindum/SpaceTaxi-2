﻿namespace SpaceTaxi_1.Taxi {
    public enum Orientation {
        Left,
        Right
    }
}